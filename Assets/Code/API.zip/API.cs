﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[System.Serializable]
public class Search //처음 query시 나온 결과
{
    public string version;
    public string title;
    public string link;
    public string pubDate;
    public string imageUrl;
    public string totalResults;
    public string startIndex;
    public string itemsPerPage;
    public string query;
    public string searchCategoryId;
    public string searchCategoryName;
    public Book[] item;
}

[System.Serializable]
public class Book // Search class -> item 배열에 있는 결과(도서에 대한 데이터)
{
    public string title; 
    public string link;
    public string author;
    public string pubDate;
    public string description;
    public string creator;
    public string isbn;
    public string isbn13;
    public string itemId;
    public string priceSales;
    public string priceStandard;
    public string stockStatus;
    public string mileage;
    public string cover;
    public string categoryId; 
    public string categoryName; 
    public string publisher; 
    public string customerReviewRank;
}


public class API : MonoBehaviour
{
    private const string URL = "http://www.aladin.co.kr/ttb/api/ItemSearch.aspx?ttbkey=ttbanny5051756001&Query=unity&QueryType=Title&MaxResults=3&start=1&SearchTarget=Book&output=js";
    private const string API_KEY = "ttbanny5051756001";
    public Text responseText;
    public Search search = new Search();

    public void Request()
    {
        WWW request = new WWW(URL);
        StartCoroutine(OnResponse(request));
       
    }

    private IEnumerator OnResponse(WWW req)
    {
        yield return req;
        string json = req.text;
        string text1 = "", text2 = "";
        json = json.Replace(";", ""); //마지막 ; 없애기
        search = JsonUtility.FromJson<Search>(json); //이제 여기서 item(책) 추출해야 함

        for(int i = 0; i < search.item.Length; i++)
        {
            text2 = "책 제목 : " + search.item[i].title + "\n"+ "저자 : "+search.item[i].author+"\n"+search.item[i].description+"\n\n\n"; 
            text1 += text2;
        }

        responseText.text = text1;

    }

}


