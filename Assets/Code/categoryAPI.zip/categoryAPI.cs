﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


[System.Serializable]
public class Search //처음 query시 나온 결과
{
	public string version;
	public string title;
	public string link;
	public string pubDate;
	public string imageUrl;
	public string totalResults;
	public string startIndex;
	public string itemsPerPage;
	public string query;
	public string searchCategoryId;
	public string searchCategoryName;
	public Book[] item;
}

[System.Serializable]
public class Book // Search class -> item 배열에 있는 결과(도서에 대한 데이터)
{
	public string title; 
	public string link;
	public string author;
	public string pubDate;
	public string description;
	public string creator;
	public string isbn;
	public string isbn13;
	public string itemId;
	public string priceSales;
	public string priceStandard;
	public string stockStatus;
	public string mileage;
	public string cover;
	public string categoryId; 
	public string categoryName; 
	public string publisher; 
	public string customerReviewRank;
	public void coverReplace(){this.cover = this.cover.Replace("sum", "500");}
}




public class categoryAPI : MonoBehaviour
{
	private const string apiurl= "http://www.aladin.co.kr/ttb/api/ItemSearch.aspx?ttbkey=ttbanny5051756001&QueryType=Title&MaxResults=1&start=1&SearchTarget=Book&output=js";
	public static string[] Titles = { "&Query=스마트 경영학", "&Query=마케팅 조사론",
		"&Query=거시금융경제학", "&Query=쉽게 배우는 기계공학 개론", "&Query=컴퓨터 구조 및 설계",
		"&Query=최신 표면처리공학", "&Query=범죄수사법 실무","&Query=표준국어문법론","&Query=방송학 개론"};
	string URL;
	//	public Text responseText;
	public Search[] search = new Search[9];
	public string image;
	public MeshRenderer[] cubeRenderer;
	//public MeshRenderer cubeRenderer2;
	public int i;
	WWW request;
	WWW www;
	public Text[] Text1;
	string text2;

	void Start()
	{
		StartCoroutine("OnResponse");
	}

	public IEnumerator OnResponse()
	{
		for(i=0;i<9;i++){
			URL = apiurl + Titles[i];
			request = new WWW(URL);

			yield return request;
			string json = request.text;

			//string text1 = "", text2 = "";
			json = json.Replace(";", ""); //마지막 ; 없애기

			search[i]= JsonUtility.FromJson<Search>(json); //이제 여기서 item(책) 추출해야 함

			text2 = "책 제목 : " + search[i].item[0].title + "\n\n"+ "저자 : "
				+search[i].item[0].author+"\n\n"+"출판사 : " +search[i].item[0].publisher+"\n\n"+
				"정가 : " +search[i].item[0].priceStandard+"\n\n"+"출간일 : " +
				search[i].item[0].pubDate+"\n\n"+search[i].item[0].description; 
			Text1[i].text = String.Copy(text2);

			search[i].item[0].coverReplace();
			image = search[i].item[0].cover;

			www = new WWW(image);
			yield return www;
			cubeRenderer[i].material.mainTexture = www.texture;
		}
	}
}
